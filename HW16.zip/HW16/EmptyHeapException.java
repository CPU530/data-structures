public class EmptyHeapException extends RuntimeException {
    public EmptyHeapException(String message) {
        super(message);
    }
}
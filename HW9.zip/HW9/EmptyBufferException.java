public class EmptyBufferException extends RuntimeException {
    public EmptyBufferException() {
        super();
    }

    public EmptyBufferException(String message) {
        super(message);
    }
}
